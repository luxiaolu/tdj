echo Test graph with easy configuration file...
./graph easy
echo

echo Test graph with RPN configuration file...
./graph operator
echo

echo Test nblock with easy configuration file...
./nblock easy
echo

echo Test nblock with RPN configuration file...
./nblock operator
