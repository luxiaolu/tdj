#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <semaphore.h>
#include <pthread.h>

#define NODE_BUF_SIZE  26
#define NODE_EDGE_SIZE 8

typedef struct Edge {
    int head;
    int tail;
    sem_t sem;
} Edge;

typedef struct Node {
    int id;
    int comptValue;
    int comptTime;
    int *inEdges;
    int *outEdges;
    int inEdgeNum;
    int outEdgeNum;
    int inEdgeBufSize;
    int outEdgeBufSize;
    char **expression;
} Node;

int nodeNum = 0, edgeNum = 0;
Edge **edges = NULL;
Node **nodes = NULL;
int nodesBufSize = 0, edgesBufSize = 0;

int total = 0;
pthread_mutex_t totalMutex = PTHREAD_MUTEX_INITIALIZER;
time_t startTime;

int getOperand(int *p, char stack[], int *top, int nodeId) {
    int val;
    if( (*top) == 0 ) {
        fprintf(stderr, "The configure file is invalid.\n");
        return -1;
    }
    char pp = stack[--(*top)];
    if( pp == 'I') {
        val = nodeId - 'A';
    }
    else if( pp == 'V' ) {
        pthread_mutex_lock(&totalMutex);
        val = total;
        pthread_mutex_unlock(&totalMutex);
    }
    else {
        val = pp;
    }
    *p = val;
    return 0;
}

int getTwoOperand(int *p1, int *p2, char stack[], int *top, int nodeId) {
    int ret;
    ret = getOperand(p2, stack, top, nodeId);
    if( ret != 0 )
        return ret;

    ret = getOperand(p1, stack, top, nodeId);
    if( ret != 0 )
        return ret;
    return 0;
}

int evalExpr(char **tokens, int nodeId) {
    char stack[512];
    int top = 0;

    int pos = 0;
    while(1) {
        char *cur = tokens[pos];
        if(cur == NULL)
            break;

        char op = cur[0];
        int p1, p2, ret;
        switch(op) {
            case '+': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 + p2;
                break;
            }
            case '-': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 - p2;
                break;
            }
            case '*': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 * p2;
                break;
            }
            case '/': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 / p2;
                break;
            }
            case '%': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 % p2;
                break;
            }
            case 'I':
            case 'V': {
                stack[top++] = op;
                break;
            }
            default : {
                stack[top++] = atoi(cur);
                break;
            }
        }
        pos++;
    }
    if( top != 0 )
        return stack[--top];
    else
        return 0;
}

int compute(Node *node) {
    int val;
    if(node->expression == NULL) {
        val = node->comptValue;
    }
    else {
        val = evalExpr(node->expression, node->id);
    }

    pthread_mutex_lock(&totalMutex);
    total += val;
    pthread_mutex_unlock(&totalMutex);
    return val;
}

void* executeNode(void *n) {
    Node *node = (Node*)n;
    //wait for all in edge
    int i;
    for(i=0; i<node->inEdgeNum; i++) {
        Edge *edge = edges[node->inEdges[i]];
        sem_wait(&(edge->sem));
    }
    //compute
    int val = compute(node);
    //sleep
    sleep(node->comptTime);
    //post all out edge
    for(i=0; i<node->outEdgeNum; i++) {
        Edge *edge = edges[node->outEdges[i]];
        sem_post(&(edge->sem));
    }
    //msg
    fprintf(stdout,
            "Node %c compute a value of %d after %d seconds.\n",
            node->id,
            val,
            time(0) - startTime);
    pthread_exit(NULL);
}

void initNode(Node *node, char **tokens) {
    // id
    node->id = tokens[0][0];
    // compt value
    node->comptValue = atoi(tokens[1]);
    // compt time
    node->comptTime = atoi(tokens[2]);
    // add to node list
    if(nodeNum >= nodesBufSize) {
        nodes = (Node**)realloc(nodes, (nodesBufSize + NODE_BUF_SIZE) * sizeof(Node*));
        nodesBufSize += NODE_BUF_SIZE;
    }
    nodes[nodeNum] = node;
    nodeNum++;
    // others
    node->inEdgeNum = 0;
    node->outEdgeNum = 0;
    node->inEdges = (int*)malloc(NODE_EDGE_SIZE * sizeof(int));
    node->outEdges = (int*)malloc(NODE_EDGE_SIZE * sizeof(int));
    node->inEdgeBufSize = NODE_EDGE_SIZE;
    node->outEdgeBufSize = NODE_EDGE_SIZE;

    node->expression = NULL;
    int position = 3;
    int isExpr = 0;
    int exprPos = 0;
    int tokenSize = 3;

    while(1) {
        char *cur = tokens[position];
        if(!cur) {
            tokenSize++;
            break;
        }
        if(strcmp(cur, "=") == 0) {
            isExpr = 1;
            exprPos = position;
            position++;
            tokenSize++;
            continue;
        }
        if( !isExpr ) {
            // edge
            Edge *edge = (Edge*)malloc(sizeof(Edge*));
            edge->head = tokens[position][0];
            edge->tail = node->id;
            sem_init(&(edge->sem), 0, 0);
            position++;
            tokenSize++;

            // add to edge list
            if(edgeNum >= edgesBufSize) {
                edges = (Edge**)realloc(edges, (edgesBufSize + NODE_BUF_SIZE) * sizeof(Edge*));
                edgesBufSize += NODE_BUF_SIZE;
            }
            edges[edgeNum] = edge;
            edgeNum++;
        }
        else {
            position++;
            tokenSize++;
        }
    }

    if( isExpr ) {
        node->expression = (char**)malloc((tokenSize - exprPos - 1) * sizeof(char*));
        int pos = 0;
        int copyPos = exprPos + 1;
        while(1) {
            char *tmp = (char*)malloc(512 * sizeof(char));
            if(tokens[copyPos] != NULL){
                strcpy(tmp, tokens[copyPos]);
            }
            else {
                tmp = NULL;
            }
            node->expression[pos] = tmp;
            if(tokens[copyPos] == NULL)
                break;

            pos++;
            copyPos++;
        }
    }
}

void freeNodesEdges() {
    int i;
    for(i=0; i<nodeNum; i++) {
        Node *node = nodes[i];
        free(node->inEdges);
        free(node->outEdges);
        free(node);
    }
    for(i=0; i<edgeNum; i++) {
        Edge *edge = edges[i];
        free(edge);
    }
    free(nodes);
    free(edges);
}

Node* getNode(int id) {
    int i;
    for(i=0; i<nodeNum; i++) {
        Node *node = nodes[i];
        if(node->id == id)
            return node;
    }
    return NULL;
}

void addEdgeToNode() {
    int i;
    for(i=0; i<edgeNum; i++) {
        Edge *edge = edges[i];
        Node *headNode = getNode(edge->head);
        Node *tailNode = getNode(edge->tail);

        // head node
        if(!headNode)
            fprintf(stderr, "The configuration file is invalid, can't find Node %c.\n", edge->head);

        if(headNode->outEdgeNum >= headNode->outEdgeBufSize) {
            headNode->outEdgeBufSize += NODE_EDGE_SIZE;
            headNode->outEdges = (int*)realloc(headNode->outEdges, headNode->outEdgeBufSize);
        }

        headNode->outEdges[headNode->outEdgeNum] = i;
        headNode->outEdgeNum++;


        // tail node
        if(!tailNode)
            fprintf(stderr, "The configuration file is invalid, can't find Node %c.\n", edge->head);

        if(tailNode->inEdgeNum >= tailNode->inEdgeBufSize) {
            tailNode->inEdgeBufSize += NODE_EDGE_SIZE;
            tailNode->inEdges = (int*)realloc(tailNode->inEdges, tailNode->inEdgeBufSize);
        }
        tailNode->inEdges[tailNode->inEdgeNum] = i;
        tailNode->inEdgeNum++;
    }
}

void parseLine(char* line) {
    int bufsize = 20, position = 0;
    char **tokens = (char**)malloc(bufsize* sizeof(char*));
    char *token;

    token = strtok(line, " ");
    while (token != NULL) {
        tokens[position] = token;
        position++;

        if( position >= bufsize ) {
            bufsize += 20;
            tokens = (char**)realloc(tokens, bufsize * sizeof(char*));
        }

        token = strtok(NULL, " ");
    }
    tokens[position] = NULL;
    if(position < 3) {
        fprintf(stderr, "\"%s\" is invalid.\n", line);
    }

    Node *node = (Node*)malloc(sizeof(Node));
    initNode(node, tokens);
}

void parseConfig(FILE *file) {
    char *line = NULL;
    size_t bufsize = 0;
    while(getline(&line, &bufsize, file) != -1) {
        parseLine(line);
    }
    free(line);
}

int main(int argc, char** argv)
{
    // init
    nodes = (Node**)malloc(NODE_BUF_SIZE * sizeof(Node*));
    edges = (Edge**)malloc(NODE_BUF_SIZE * sizeof(Edge*));
    startTime = time(0);
    nodesBufSize = NODE_BUF_SIZE;
    edgesBufSize = NODE_BUF_SIZE;
    // parse the config file
    if( argc < 2 ) {
        fprintf(stderr, "please input the configuration file.\n");
        exit(EXIT_FAILURE);
    }

    FILE *configFile = fopen(argv[1], "r");
    if(!configFile) {
        fprintf(stderr, "Can't open file %s, permission deined.\n");
        exit(EXIT_FAILURE);
    }

    parseConfig(configFile);

    // add edge to node
    addEdgeToNode();

    // execute
    int i;
    pthread_t threads[nodeNum];
    for(i=0; i<nodeNum; i++) {
        pthread_t pid;
        pthread_create(&pid, NULL, executeNode, nodes[i]);
        threads[i] = pid;
    }
    for(i=0; i<nodeNum; i++) {
        pthread_join(threads[i], NULL);
    }

    fprintf(stdout,
            "Total computation resulted in a value of %d after %d seconds.\n",
            total,
            time(0) - startTime);
    freeNodesEdges();
    return EXIT_SUCCESS;
}


