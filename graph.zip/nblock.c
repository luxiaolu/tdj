#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <semaphore.h>
#include <pthread.h>

#define NODE_BUF_SIZE  26
#define NODE_EDGE_SIZE 8

typedef struct Edge {
    int head;
    int tail;
    sem_t sem;
} Edge;

typedef struct Node {
    int id;
    int comptValue;
    int comptTime;
    char **expression;
    int nblockId;
    int outNBlockIds[26];
    int outNBlockNum;

    int inNodeIds[26];
    int inNodeNum;
} Node;

typedef struct NBlock {
    int id;
    int blockNum;
    pthread_mutex_t lock;
    pthread_cond_t cond;
} NBlock;

int nodeNum = 0;
Node **nodes = NULL;
int nodesBufSize = 0;

NBlock *nblocks[26];
int nblockNum = 0;

int total = 0;
pthread_mutex_t totalMutex = PTHREAD_MUTEX_INITIALIZER;
time_t startTime;

int createNBlock(int n) {
    NBlock *nblock = (NBlock*)malloc(sizeof(NBlock));
    nblock->blockNum = n;
    nblock->lock = PTHREAD_MUTEX_INITIALIZER;
    nblock->cond = PTHREAD_COND_INITIALIZER;
    nblocks[nblockNum] = nblock;
    int blockId = nblockNum;
    nblockNum++;
    return blockId;
}

void signalNBlock(int id) {
    NBlock *nblock = nblocks[id];
    pthread_mutex_lock(&(nblock->lock));
    nblock->blockNum--;
    pthread_mutex_unlock(&(nblock->lock));
    if(nblock->blockNum == 0)
        pthread_cond_signal(&(nblock->cond));
}

void waitNBlock(int id) {
    NBlock *nblock = nblocks[id];
    if(nblock->blockNum == 0)
        return;
    pthread_mutex_lock(&(nblock->lock));
    pthread_cond_wait(&(nblock->cond), &(nblock->lock));
    pthread_mutex_unlock(&(nblock->lock));
}

void destroyNBlock(int id) {
    NBlock *nblock = nblocks[id];
    pthread_mutex_destroy(&(nblock->lock));
    free(nblock);
}

int getOperand(int *p, char stack[], int *top, int nodeId) {
    int val;
    if( (*top) == 0 ) {
        fprintf(stderr, "The configure file is invalid.\n");
        return -1;
    }
    char pp = stack[--(*top)];
    if( pp == 'I') {
        val = nodeId - 'A';
    }
    else if( pp == 'V' ) {
        pthread_mutex_lock(&totalMutex);
        val = total;
        pthread_mutex_unlock(&totalMutex);
    }
    else {
        val = pp;
    }
    *p = val;
    return 0;
}

int getTwoOperand(int *p1, int *p2, char stack[], int *top, int nodeId) {
    int ret;
    ret = getOperand(p2, stack, top, nodeId);
    if( ret != 0 )
        return ret;

    ret = getOperand(p1, stack, top, nodeId);
    if( ret != 0 )
        return ret;
    return 0;
}

int evalExpr(char **tokens, int nodeId) {
    char stack[512];
    int top = 0;

    int pos = 0;
    while(1) {
        char *cur = tokens[pos];
        if(cur == NULL)
            break;

        char op = cur[0];
        int p1, p2, ret;
        switch(op) {
            case '+': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 + p2;
                break;
            }
            case '-': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 - p2;
                break;
            }
            case '*': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 * p2;
                break;
            }
            case '/': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 / p2;
                break;
            }
            case '%': {
                ret = getTwoOperand(&p1, &p2, stack, &top, nodeId);
                if( ret != 0 )
                    return 0;
                else
                    stack[top++] = p1 % p2;
                break;
            }
            case 'I':
            case 'V': {
                stack[top++] = op;
                break;
            }
            default : {
                stack[top++] = atoi(cur);
                break;
            }
        }
        pos++;
    }
    if( top != 0 )
        return stack[--top];
    else
        return 0;
}

int compute(Node *node) {
    int val;
    if(node->expression == NULL) {
        val = node->comptValue;
    }
    else {
        val = evalExpr(node->expression, node->id);
    }

    pthread_mutex_lock(&totalMutex);
    total += val;
    pthread_mutex_unlock(&totalMutex);
    return val;
}

void* executeNode(void *n) {
    Node *node = (Node*)n;
    //wait for nblock
    waitNBlock(node->nblockId);
    //compute
    int val = compute(node);
    //sleep
    sleep(node->comptTime);
    //msg
    fprintf(stdout,
            "Node %c compute a value of %d after %d seconds.\n",
            node->id,
            val,
            time(0) - startTime);
    //signal to depended nblock
    int i;
    for(i=0; i<node->outNBlockNum; i++) {
        signalNBlock(node->outNBlockIds[i]);
    }
    pthread_exit(NULL);
}

void initNode(Node *node, char **tokens) {
    // id
    node->id = tokens[0][0];
    // compt value
    node->comptValue = atoi(tokens[1]);
    // compt time
    node->comptTime = atoi(tokens[2]);
    // add to node list
    if(nodeNum >= nodesBufSize) {
        nodes = (Node**)realloc(nodes, (nodesBufSize + NODE_BUF_SIZE) * sizeof(Node*));
        nodesBufSize += NODE_BUF_SIZE;
    }
    nodes[nodeNum] = node;
    nodeNum++;
    // others
    node->inNodeNum = 0;
    node->outNBlockNum = 0;
    node->expression = NULL;

    int position = 3;
    int isExpr = 0;

    int exprPos = 0;
    int tokenSize = 3;

    while(1) {
        char *cur = tokens[position];
        if(!cur) {
            tokenSize++;
            break;
        }
        if(strcmp(cur, "=") == 0) {
            isExpr = 1;
            exprPos = position;
            position++;
            tokenSize++;
            continue;
        }
        if( !isExpr ) {
            node->inNodeIds[node->inNodeNum] = tokens[position][0];
            node->inNodeNum++;

            position++;
            tokenSize++;
        }
        else {
            position++;
            tokenSize++;
        }
    }

    if( isExpr ) {
        node->expression = (char**)malloc((tokenSize - exprPos - 1) * sizeof(char*));
        int pos = 0;
        int copyPos = exprPos + 1;
        while(1) {
            char *tmp = (char*)malloc(512 * sizeof(char));
            if(tokens[copyPos] != NULL){
                strcpy(tmp, tokens[copyPos]);
            }
            else {
                tmp = NULL;
            }
            node->expression[pos] = tmp;
            if(tokens[copyPos] == NULL)
                break;

            pos++;
            copyPos++;
        }
    }
}

void freeNodes() {
    int i;
    for(i=0; i<nodeNum; i++) {
        Node *node = nodes[i];
        destroyNBlock(node->nblockId);
        free(node);
    }
    free(nodes);
}

Node* getNode(int id) {
    int i;
    for(i=0; i<nodeNum; i++) {
        Node *node = nodes[i];
        if(node->id == id)
            return node;
    }
    return NULL;
}

void addNBlockToNode() {
    int i;

    for(i=0; i<nodeNum; i++) {
        Node* node = nodes[i];
        node->nblockId = createNBlock(node->inNodeNum);
    }

    for(i=0; i<nodeNum; i++) {
        Node* node = nodes[i];
        int j;
        for(j=0; j<node->inNodeNum; j++) {
            Node* inNode = getNode(node->inNodeIds[j]);
            inNode->outNBlockIds[inNode->outNBlockNum] = node->nblockId;
            inNode->outNBlockNum++;
        }
    }
}

void parseLine(char* line) {
    int bufsize = 20, position = 0;
    char **tokens = (char**)malloc(bufsize* sizeof(char*));
    char *token;

    token = strtok(line, " ");
    while (token != NULL) {
        tokens[position] = token;
        position++;

        if( position >= bufsize ) {
            bufsize += 20;
            tokens = (char**)realloc(tokens, bufsize * sizeof(char*));
        }

        token = strtok(NULL, " ");
    }
    tokens[position] = NULL;
    if(position < 3) {
        fprintf(stderr, "\"%s\" is invalid.\n", line);
    }

    Node *node = (Node*)malloc(sizeof(Node));
    initNode(node, tokens);
}

void parseConfig(FILE *file) {
    char *line = NULL;
    size_t bufsize = 0;
    while(getline(&line, &bufsize, file) != -1) {
        parseLine(line);
    }
    free(line);
}

int main(int argc, char** argv)
{
    // init
    nodes = (Node**)malloc(NODE_BUF_SIZE * sizeof(Node*));
    startTime = time(0);
    nodesBufSize = NODE_BUF_SIZE;
    // parse the config file
    if( argc < 2 ) {
        fprintf(stderr, "please input the configuration file.\n");
        exit(EXIT_FAILURE);
    }

    FILE *configFile = fopen(argv[1], "r");
    if(!configFile) {
        fprintf(stderr, "Can't open file %s, permission deined.\n");
        exit(EXIT_FAILURE);
    }

    parseConfig(configFile);

    // add nblock
    addNBlockToNode();

    // execute
    int i;
    pthread_t threads[nodeNum];
    for(i=0; i<nodeNum; i++) {
        pthread_t pid;
        pthread_create(&pid, NULL, executeNode, nodes[i]);
        threads[i] = pid;
    }
    for(i=0; i<nodeNum; i++) {
        pthread_join(threads[i], NULL);
    }

    fprintf(stdout,
            "Total computation resulted in a value of %d after %d seconds.\n",
            total,
            time(0) - startTime);
    freeNodes();
    return EXIT_SUCCESS;
}


